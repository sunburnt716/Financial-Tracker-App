export const mockTransactions = [
    { name : "Groceries", price: 150, date: "2025-10-01"},
    { name : "Gas", price: 45, date: "2025-10-02"},
    { name : "Rent", price: 1200, date: "2025-10-03"}
]